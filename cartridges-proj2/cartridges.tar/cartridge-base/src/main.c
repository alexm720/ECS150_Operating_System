#include <stdint.h>

int main() {
    
    return 0;
}
