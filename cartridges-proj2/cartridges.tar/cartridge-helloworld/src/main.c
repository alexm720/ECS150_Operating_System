#include <stdint.h>
#include "RVCOS.h"

int main() {
    RVCWriteText("Hello World!",12);
    return 0;
}
